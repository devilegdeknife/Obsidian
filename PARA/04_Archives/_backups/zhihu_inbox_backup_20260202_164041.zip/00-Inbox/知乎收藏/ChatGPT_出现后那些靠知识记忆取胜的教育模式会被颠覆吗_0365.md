---
tags: [技术/AI/LLM, 学习/阅读/书单, 社会/议题/社会现象, 技术/AI/应用, 技术/AI/工具]
---
# ChatGPT 出现后，那些靠知识记忆取胜的教育模式会被颠覆吗？
[内容链接](https://www.zhihu.com/question/583015287/answer/2952743955)

第二章：读完《筚路维艰：中国社会主义路径的五次选择》这本神作后，想借助CHATGPT进行读书总结，方便我把知识点和前后联系起来，所以尝试用了CHATgpt来总结，效果如下：期间不断对提问进行编辑 最终结果还可以

当然书还是要你先读完才能分辨它是否总结的合理。我个人感觉它可以帮你进一步吃透书里的各章节的联系。

![图片描述](https://pica.zhimg.com/v2-c4c218d57bcaaada888ce272c6ed9f83_r.jpg?source=2c26e567)

![图片描述](https://pic1.zhimg.com/v2-0120c179905a98487a9d315b30a84bbc_r.jpg?source=2c26e567)

接着我按照微信读书里的目录给出详细的要求：

![图片描述](https://picx.zhimg.com/v2-c593d201eb496d2c375b8569c3966147_r.jpg?source=2c26e567)




并要求表格化，中间还有一些细节的调整： 最后它呈现的是

![图片描述](https://picx.zhimg.com/v2-194d66f1e3b9ea815221407e14de7c99_r.jpg?source=2c26e567)

我要求它细分到每个章节的小章节：




第一章：




![图片描述](https://pica.zhimg.com/v2-c0bd6722e6e6fab16c82f7ed4f4811d0_r.jpg?source=2c26e567)

第二章：

![图片描述](https://picx.zhimg.com/v2-5d94e077686104b9c940af8c5a6edcae_r.jpg?source=2c26e567)

第三章：

![图片描述](https://picx.zhimg.com/v2-7c6c4f904cf910bde718ab9161ab40ac_r.jpg?source=2c26e567)

第四章：

![图片描述](https://picx.zhimg.com/v2-76c2084a60a58d675fd987c159892c38_r.jpg?source=2c26e567)

第五章：

![图片描述](https://pic1.zhimg.com/v2-ab3fe6d4bb20d8b9840d70dadbf2d5bd_r.jpg?source=2c26e567)




附录：




![图片描述](https://picx.zhimg.com/v2-a26db9dc083d4808c5c6c8db405855c4_r.jpg?source=2c26e567)
