---
tags:
  - 技术/AI/LLM
  - 技术/AI/应用
  - 技术/AI/工具
  - 技术/AI/提示工程
  - 技术/AI/趋势
---
# ChatGPT 有哪些神奇的使用方式？
[内容链接](https://www.zhihu.com/question/570729170/answer/2925039324)

用chatgpt+midjourney生成的茶杯，全程耗时5分钟，问过景德镇的朋友根据这些图可直接生产。

![图片描述](https://picx.zhimg.com/v2-ce8441b5a028258ec613232998908d2f_r.jpg?source=2c26e567)




![图片描述](https://picx.zhimg.com/v2-2dd564e34204569cdc0c289aeb0a6116_r.jpg?source=2c26e567)




![图片描述](https://pic1.zhimg.com/v2-74195d70c6bd601701a2b674eeafa256_r.jpg?source=2c26e567)