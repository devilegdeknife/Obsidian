---
tags: [技术/AI/应用, 社会/观点/讨论, 学习/思考/观点, 生活/日常/观察, 文化/观点/评论]
---
# 如何直接从 Google Play 下载 APK 文件？
[内容链接](https://www.zhihu.com/question/20232626/answer/4104495379)

省流：[https://apkpremier.com/](https://link.zhihu.com/?target=https%3A//apkpremier.com/)

截至当前，**中国境内**仅此网站能在**不登录Google Play、不使用“全局代理”**的前提下，通过Google Play的应用网址来下载对应的apk/xapk文件。其他网站无一例外，都无法在国内访问。

顺带一提，油猴上有个脚本可以在访问Google Play时选择直接获取apk文件（其实也就是整合了几个网址罢了），其中就提到了这个网址。

这是花了一个多小时寻找的结果，希望这个网站能持续运行下去吧




还是提醒一下大伙悠着点哈，且用且珍惜
