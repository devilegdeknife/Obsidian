---
tags:
  - 技术/工具/LaTeX
  - 学习/工具/排版
  - 文化/审美/排版
  - 学习/方法/自学
  - 技术/软件工程/工具
---
# 有哪些美观实用的或者有创意的 LaTeX 模板？
[内容链接](https://www.zhihu.com/question/23042797/answer/2364076736)

好用不知道,魔改了ElegentBook模板,改完后是这个样子.

![图片描述](https://picx.zhimg.com/v2-ab07579a40089c9448bc996f4ee04972_r.jpg?source=2c26e567)

![图片描述](https://pic1.zhimg.com/v2-acf4b71d003cb9b22196d5fbd462114b_r.jpg?source=2c26e567)

![图片描述](https://pic1.zhimg.com/v2-ee2276cbb41a280d48fc1c6ec98a11ed_r.jpg?source=2c26e567)

![图片描述](https://pica.zhimg.com/v2-4f63f57ab89844a8496f4b67fb29986b_r.jpg?source=2c26e567)

![图片描述](https://pic1.zhimg.com/v2-1a0e74d6c6ecc5dc70ad4b8716b2b5f9_r.jpg?source=2c26e567)

还有一大堆定义的环境,数学环境有这些,有些是ElegentBook模板自带的,也有自己改的:

![图片描述](https://picx.zhimg.com/v2-23a1b9b17ddfe71320c7c0ec0ec2c26a_r.jpg?source=2c26e567)

![图片描述](https://picx.zhimg.com/v2-14539b738df702afdd7cf4114655abf7_r.jpg?source=2c26e567)

![图片描述](https://picx.zhimg.com/v2-a9a4e94dc30c21962cd1c4f0b6c4d955_r.jpg?source=2c26e567)

![图片描述](https://pic1.zhimg.com/v2-c2b5f885aa399ddd3696ed1ac36507a4_r.jpg?source=2c26e567)

![图片描述](https://picx.zhimg.com/v2-f73688e12b85356461bbada3f6972ad5_r.jpg?source=2c26e567)

等等很多,可以自己翻翻,还有一些代码抄录环境:

![图片描述](https://picx.zhimg.com/v2-ee1acdda8553bd2ad7bd11a9011ba11c_r.jpg?source=2c26e567)

![图片描述](https://picx.zhimg.com/v2-6bf0d46faf0eb4982f6b210cb0138dd3_r.jpg?source=2c26e567)

![图片描述](https://picx.zhimg.com/v2-e4d2064e98e1245325336e01a7f8e19c_r.jpg?source=2c26e567)

![图片描述](https://picx.zhimg.com/v2-231ad74b9cd79a7459034de3e109cd88_r.jpg?source=2c26e567)

![图片描述](https://pic1.zhimg.com/v2-397157f65a5b37af63fb1786994f1ac4_r.jpg?source=2c26e567)

![图片描述](https://picx.zhimg.com/v2-9723fd0fe453b64bf722fa0df512814e_r.jpg?source=2c26e567)

![图片描述](https://picx.zhimg.com/v2-f7585f8c4b6939bd882a88f994b969d3_r.jpg?source=2c26e567)

等等,还有很多ElegentBook自带的一些环境,版本更新历史等等,可自行尝试:

![图片描述](https://picx.zhimg.com/v2-87434ca3f5a832ccf21c5c9f85c86fae_r.jpg?source=2c26e567)

模板下载地址:
[Elegentbook魔改版 - LaTeX 工作室](https://link.zhihu.com/?target=https%3A//www.latexstudio.net/index/details/index/mid/2314.html)

Elegentbook模板下载地址:

[https://github.com/ElegantLaTeX/](https://link.zhihu.com/?target=https%3A//github.com/ElegantLaTeX/)

全新版本的下载地址：
模板下载地址

目前模板发布在了[LaTeX 工作室](https://link.zhihu.com/?target=http%3A//www.latexstudio.net/)中,这里提供了非常丰富的模板.具体下载地址如下:[VividBook - LaTeX 工作室](https://link.zhihu.com/?target=https%3A//www.latexstudio.net/index/details/index/mid/3485.html)欢迎各位大佬尝试

更新下载地址:[VividBook - LaTeX 工作室](https://link.zhihu.com/?target=https%3A//www.latexstudio.net/index/details/index/mid/3485.html)

Github地址:[https://github.com/Azure1210/VividBooK](https://link.zhihu.com/?target=https%3A//github.com/Azure1210/VividBooK)