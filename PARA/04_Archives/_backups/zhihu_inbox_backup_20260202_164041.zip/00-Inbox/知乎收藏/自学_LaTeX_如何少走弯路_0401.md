---
tags:
  - 技术/工具/LaTeX
  - 学习/方法/自学
  - 学习/工具/排版
  - 文化/审美/排版
  - 社会/观点/讨论
---
# 自学 LaTeX 如何少走弯路？
[内容链接](https://www.zhihu.com/question/30620276/answer/2654711679)

不需要专门学。上arxiv，随便打开一篇大佬或者排版漂亮的文章，点击网页右上角的other format再点Download source，这样就能下载文章的latex代码,照着模版边用边学就行了