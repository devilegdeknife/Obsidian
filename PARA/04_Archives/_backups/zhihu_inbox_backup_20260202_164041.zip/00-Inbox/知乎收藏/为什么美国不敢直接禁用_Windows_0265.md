---
tags: [社会/观点/讨论, 学习/思考/观点, 生活/日常/观察, 文化/观点/评论, 社会/议题/社会现象]
---
# 为什么美国不敢直接禁用 Windows？
[内容链接](https://www.zhihu.com/question/599897608/answer/3031093966)

知道这个网站不？！

今天禁用，明天就可以下载更好的版本，

可能补丁，比正版的都完整。

![图片描述](https://picx.zhimg.com/v2-dfa3c03243dda163208bff82f2ab12a7_r.jpg?source=2c26e567)
