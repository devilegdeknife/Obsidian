---
tags:
  - 技术/工具/LaTeX
  - 学习/工具/排版
  - 学习/方法/自学
  - 技术/工程/可视化
  - 文化/审美/排版
---
# 怎么用latex画这种图？
[内容链接](https://www.zhihu.com/question/527641163/answer/2440053650)

[]()

用LaTeX可以画楼主的图，先画静态图，然后脚本渲染成动态图形。

![图片描述](https://pic1.zhimg.com/v2-95b8e41f90fd48d7bfa0470e1d368643_r.jpg?source=2c26e567)

然后用脚本批量修改参数，生成一系列图片，用ffmpeg合成动图

[https://www.zhihu.com/video/1498097254934736896](https://link.zhihu.com/?target=https%3A//www.zhihu.com/video/1498097254934736896)